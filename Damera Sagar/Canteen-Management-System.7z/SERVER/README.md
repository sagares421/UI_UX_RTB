## Canteen management System 'Server'

In the project directory, you can run:

### To install depencencies

Runs`npm install`

### To start server

`node index.js OR nodemon`

`OPEN: http://localhost:4000`