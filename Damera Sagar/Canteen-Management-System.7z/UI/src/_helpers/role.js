export const Role = {
    Admin: 'Admin',
    Employee: 'Employee'  
}