export const orderConstants = {
    GET_ORDER: 'GET_ORDER',
    ADD_ORDER: 'ADD_ORDER',
    UPDATE_ORDER: 'UPDATE_ORDER',
    DELETE_ORDER: 'DELETE_ORDER'
};
