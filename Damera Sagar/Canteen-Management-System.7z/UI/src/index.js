import React from 'react';
import ReactDOM from 'react-dom';
import './index.scss';
import App from './App/App';
import * as serviceWorker from './serviceWorker';

// Material UI Theme
import {createMuiTheme} from '@material-ui/core/styles';
import {ThemeProvider} from '@material-ui/styles';

// Redux Setup
import reducer from './_reducers'
import middleware from './_middlewares'
import {Provider} from 'react-redux'
import {createStore} from 'redux'

const store = createStore(reducer, middleware)



const theme = createMuiTheme({
  palette: {
    primary: {
      dark: '#1165c1',
      light: '#95c2ff',
      main: '#5d92f4'
    },
    secondary: {
      dark: '#009e8d',
      light: '#63ffef',
      main: '#00d0bd'
    }
  },
  shape: {
    borderRadius: 5
  }
});

ReactDOM.render(
  <Provider store={store}>
  <ThemeProvider theme={theme}>
    <App/>
  </ThemeProvider>
</Provider>, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls. Learn
// more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
