import React from 'react';
import {makeStyles} from '@material-ui/core/styles';

import {Grid, Paper} from '@material-ui/core';

// Layouts
import Nav from '../../_layouts/Nav/Nav';

// Custom Components
import SimpleCard from '../../_components/Card/SimpleCard';
import ProductCard from '../../_components/Card/ProductCard';
import MuiDataTable from '../../_components/Table/MuiDataTable';

const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: 'center',
    color: theme.palette.text.secondary
  }
}));

const EmployeeDashboard = () => {
  const classes = useStyles();
  return (
    <React.Fragment>
      <Nav/>
      <div className={classes.root}>
        <Grid container spacing={3}>
          <Grid item xs={6}>
            <MuiDataTable title="Products List" data="data"/>
          </Grid>
          <Grid item xs={6}>
            <MuiDataTable title="Orders List" data="data"/>
          </Grid>
        </Grid>
      </div>
    </React.Fragment>
  );
}

export default EmployeeDashboard;
