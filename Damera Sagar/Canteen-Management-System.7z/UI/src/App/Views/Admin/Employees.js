import React from 'react';
import {Grid, Paper} from '@material-ui/core';
import {makeStyles} from '@material-ui/core/styles';

// Layouts
import Nav from '../../_layouts/Nav/Nav';

// Custom Components
import MuiDataTable from '../../_components/Table/MuiDataTable';

const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: 'center',
    color: theme.palette.text.secondary
  }
}));

const AdminEmployees = () => {
  const classes = useStyles();
  return (
    <React.Fragment>
      <Nav />

      <div className={classes.root}>
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <MuiDataTable title="Employees List"/>
          </Grid>
        </Grid>
      </div>
    </React.Fragment>
  );
}

export default AdminEmployees;
