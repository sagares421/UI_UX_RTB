import React, {Component} from 'react';
import {Grid, Paper} from '@material-ui/core';
import {makeStyles} from '@material-ui/core/styles';

// Custom Components
import SimpleCard from '../../_components/Card/SimpleCard';
import MuiDataTable from '../../_components/Table/MuiDataTable';

// Layouts
import Nav from '../../_layouts/Nav/Nav';

const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: 'center',
    color: theme.palette.text.secondary
  }
}));

const AdminDashboard = () => {
  const classes = useStyles();
  return (
    <React.Fragment>
      <Nav />
      <div className={classes.root}>
        <Grid container spacing={3}>
          <Grid item xs={3}>
            <SimpleCard>
              <p>Hello</p>
            </SimpleCard>
          </Grid>
          <Grid item xs={3}>
            <SimpleCard>
              <p>Hello</p>
            </SimpleCard>
          </Grid>
          <Grid item xs={3}>
            <SimpleCard>
              <p>Hello</p>
            </SimpleCard>
          </Grid>
          <Grid item xs={3}>
            <SimpleCard>
              <p>Hello</p>
            </SimpleCard>
          </Grid>
          <Grid item xs={12}>
            <MuiDataTable title="Products List" data="data"/>
          </Grid>
        </Grid>
      </div>
    </React.Fragment>
  );
}

export default AdminDashboard;
