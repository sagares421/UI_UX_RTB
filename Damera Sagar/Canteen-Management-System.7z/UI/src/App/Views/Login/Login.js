import React from 'react';
import {makeStyles} from '@material-ui/core/styles';

// Material UI
import {Paper, Typography, Grid, TextField, Button} from '@material-ui/core';

const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1
  },
  paper: {
    marginTop: theme.spacing(10),
    padding: theme.spacing(2),
    textAlign: 'center',
    color: theme.palette.text.secondary
  },
  textField:{
    width: '100%'
  },
  button:{
      width: '100%'
  }
}));

const Login = () => {
  const classes = useStyles();
  const [values,
    setValues] = React.useState({name: '', age: '', multiline: 'Controlled', currency: 'EUR'});

  const handleChange = name => event => {
    setValues({
      ...values,
      [name]: event.target.value
    });
  };

  return (
    <div className={classes.root}>
      <Grid
        container
        direction="row"
        justify="center"
        alignItems="center"
        spacing={3}>
        <Grid item xs={3}>
          <Paper className={classes.paper}>
            <Typography variant="h3" gutterBottom>CANTEEN</Typography>
            <div className={classes.input}>
              <TextField
                id="standard-name"
                label="Name"
                className={classes.textField}
                value={values.name}
                onChange={handleChange('name')}
                margin="normal"/>
            </div>
            <div className={classes.input}>
              <TextField
                id="standard-name"
                label="Password"
                type="password"
                className={classes.textField}
                value={values.name}
                onChange={handleChange('name')}
                margin="normal"/>
            </div>
            <Button variant="contained" color="primary" className={classes.button}>
              Login
            </Button>
          </Paper>
        </Grid>
      </Grid>
    </div>
  );
}

export default Login;
