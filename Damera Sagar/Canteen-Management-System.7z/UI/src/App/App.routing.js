import React from "react";
import {connect} from 'react-redux';
import {history, Role} from '../_helpers';
import {BrowserRouter, Switch, Route} from "react-router-dom";

import {Container} from '@material-ui/core';

// Protected Route
import {PrivateRoute} from '../_helpers/PrivateRoute'

// Components
import AdminDashboard from './Views/Admin/Dashboard';
import AdminEmployees from './Views/Admin/Employees';
import AdminOrders from './Views/Admin/Orders';
import EmployeeDashboard from './Views/Employee/Dashboard';
import Login from './Views/Login/Login';

function AppRouting() {
  return (
    <BrowserRouter>
      <div className="main">
        <Container maxWidth="xl">
          <Switch>
            <PrivateRoute
              path="/admin/dashboard"
              exact
              component={AdminDashboard}
              roles={[Role.Admin]}/>
            <PrivateRoute
              path="/admin/employees"
              exact
              component={AdminEmployees}
              roles={[Role.Admin]}/>
            <PrivateRoute
              path="/admin/orders"
              exact
              component={AdminOrders}
              roles={[Role.Admin]}/>
            <PrivateRoute
              path="/employee/dashboard"
              exact
              component={EmployeeDashboard}
              roles={[Role.Employee]}/>
            <Route path="/" exact component={Login}/>
          </Switch>
        </Container>
      </div>
    </BrowserRouter>
  );
}

export default AppRouting;
