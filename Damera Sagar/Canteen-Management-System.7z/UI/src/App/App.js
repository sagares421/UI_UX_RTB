import React from 'react';
import './App.scss';

// Components
import AppRouting from './App.routing'

function App() {
  return (
    <AppRouting />
  );
}

export default App;
