import React from 'react';
import TopNav from './TopNav';
import SideNav from './SideNav';

const Nav = () => {
  const [state,
    setState] = React.useState({open: false});

  const sideNavToggle = event => {
    if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
      return;
    }

    setState({
      ...state,
      open: !state.open
    });
  };
  return (
    <React.Fragment>
        <TopNav openSideNav={sideNavToggle}/>
        <SideNav closeSideNav={sideNavToggle} open={state.open}/>
    </React.Fragment>
  );
}

export default Nav;
