import React from 'react';
import {makeStyles} from '@material-ui/core/styles';
import {
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  IconButton,
  Typography,
  Divider
} from '@material-ui/core';

import {NavLink} from 'react-router-dom';

// Material UI Icons
import CloseIcon from '@material-ui/icons/Close';
import DashboardIcon from '@material-ui/icons/Dashboard';
import PeopleIcon from '@material-ui/icons/People';
import AttachMoneyIcon from '@material-ui/icons/AttachMoney';

const useStyles = makeStyles({
  listContainer: {
    width: 250
  },
  list: {
    paddingTop: '0px'
  },
  logo: {
    width: '100%',
    paddingRight: '0px'
  },
  IconClose: {
    color: '#DB4437'
  },
  IconDashboard: {
    color: '#4285F4'
  },
  IconLogs: {
    color: '#0F9D58'
  },
  IconDocs: {
    color: '#F4B400'
  },
  navLink:{
    color: 'rgba(0, 0, 0, 0.87)',
    textDecoration: 'none'
  }
});

export default function SideNav(props) {
  const classes = useStyles();
  const [state,
    setState] = React.useState({open: props.open});

  const sideList = () => (
    <div
      className={classes.listContainer}
      role="presentation"
      onClick={props.closeSideNav}
      onKeyDown={props.closeSideNav}>
      <List className={classes.list}>
        <ListItem button key="Cloak" className={classes.logo}>
          <Typography variant="h6" className={classes.logo}>Canteen
          </Typography>
          <ListItemIcon>
            <IconButton color="inherit" onClick={props.closeSideNav}>
              <CloseIcon/>
            </IconButton>
          </ListItemIcon>
        </ListItem>
        <Divider/>
        <NavLink to="/admin/dashboard" className={classes.navLink}>
          <ListItem button key="Dashboard">
            <ListItemIcon><DashboardIcon className={classes.IconDashboard}/></ListItemIcon>
            <ListItemText primary="Dashboard"/>
          </ListItem>
        </NavLink>
        <Divider/>
        <NavLink to="/admin/employees" className={classes.navLink}>
          <ListItem button key="Employees">
            <ListItemIcon><PeopleIcon className={classes.IconLogs}/></ListItemIcon>
            <ListItemText primary="Employees"/>
          </ListItem>
        </NavLink>
        <Divider/>
        <NavLink to="/admin/orders" className={classes.navLink}>
          <ListItem button key="Orders">
            <ListItemIcon><AttachMoneyIcon className={classes.IconClose}/></ListItemIcon>
            <ListItemText primary="Orders"/>
          </ListItem>
        </NavLink>
        <Divider/>
      </List>
    </div>
  );

  return (
    <div>
      <Drawer open={props.open} onClose={props.closeSideNav}>
        {sideList()}
      </Drawer>
    </div>
  );
}
