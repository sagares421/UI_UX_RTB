import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';

const useStyles = makeStyles({
    card: {
      minWidth: 275
    },
  });

const SimpleCard = (props) => {
    const classes = useStyles();

    return (
        <React.Fragment>
            <Card className={classes.card}>
                {props.children}
            </Card>
        </React.Fragment>
    );
}

export default SimpleCard;
