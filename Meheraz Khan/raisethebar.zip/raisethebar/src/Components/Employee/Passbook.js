import React from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/dist/styles/ag-grid.css";
import "ag-grid-community/dist/styles/ag-theme-balham.css";

class Passbook extends React.Component {
  constructor(props) {
    super(props);
    this.columns = ['Date', 'Payee', 'Amount']
    this.schemaData = [
      {'Date' : 'Pasta', 'Payee' : '10', 'Amount' : '10'},
      {'Date' : 'Noodles', 'Payee' : '20', 'Amount' : '12'},
      {'Date' : 'Samosa', 'Payee' : '15', 'Amount' : '15'},
      {'Date' : 'Tea', 'Payee' : '10', 'Amount' : '8'},
      {'Date' : 'Coffee', 'Payee' : '20', 'Amount' : '9'},
      {'Date' : 'Maggi', 'Payee' : '15', 'Amount' : '7'},
      {'Date' : 'Pizza', 'Payee' : '12', 'Amount' : '15'},
      {'Date' : 'Patties', 'Payee' : '18', 'Amount' : '10'},
      {'Date' : 'Ice Cream', 'Payee' : '15', 'Amount' : '11'},
      {'Date' : 'Noodles', 'Payee' : '20', 'Amount' : '16'},
      {'Date' : 'Manchurian', 'Payee' : '10', 'Amount' : '19'},
      {'Date' : 'Idli', 'Payee' : '10', 'Amount' : '23'},
      {'Date' : 'Dosa', 'Payee' : '10', 'Amount' : '7'},
      {'Date' : 'Cake', 'Payee' : '10', 'Amount' : '5'},
      {'Date' : 'Sandwich', 'Payee' : '10', 'Amount' : '12'},
      {'Date' : 'Juice', 'Payee' : '10', 'Amount' : '16'}
    ]
  }

  displaySchemaHeader(){
    
    let colDefs = [];
this.columns.map(item => {
  let colObj = {
          headerName: item,
          field : item,
          sortable : true,
          width : 395,
          filter : true
        }
        colDefs.push(colObj);  
})
return colDefs
 }
    
    displaySchemaData() {
      let rowData = []
      let schemaData = this.schemaData;
      schemaData.map(rows => {
        let obj= {}
        this.columns.map(cols => {
          obj[cols] = rows[cols];
        })
        rowData.push(obj);
      })
      return rowData
    }


  render() {
    return (
      <div className="col-lg-12">
<p className="passbook-heading">Wallet Balance : Rs 45</p>
<p className="passbook-heading">Previous Transactions :</p>
           <div
              style={{ height: "500px", width: "100%" }}
              className="ag-theme-balham"
            >
              <AgGridReact 
                columnDefs={this.displaySchemaHeader()}
                rowData={this.displaySchemaData()}
              />
            </div>
            </div>

    )}}
    export default Passbook