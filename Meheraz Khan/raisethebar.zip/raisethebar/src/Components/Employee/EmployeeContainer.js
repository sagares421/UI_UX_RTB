import React from 'react';
import DailyItems from '../admin/DailyItems';
import Accounts from './Accounts';
import Passbook from './Passbook';

class EmployeeContainer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            addClass: ''
        }
    }

    renderSwitch() {
        switch (this.state.addClass) {
            case 'accounts':
              return <Accounts />;
                case 'dailymenu':
                return <DailyItems typename = {this.state.addClass} />;
              case 'passbook':
                  return <Passbook/>;
        }
    }

    handleClick(id) {
        
        this.setState({
            addClass: id
        });
    }

render(){
    return (
        <div className="admin-portal">
            <p className="admin-heading">Welcome to Employee Portal!</p>
            <div className="left-menu">
            <ul className="list-style-none">
                <li className="admin-option" onClick={this.handleClick.bind(this, 'accounts')}><span>Manage Account</span></li>
                <li className="admin-option" onClick={this.handleClick.bind(this, 'dailymenu')}><span>Items Of The Day</span></li>
                <li className="admin-option" onClick={this.handleClick.bind(this, 'passbook')}><span>View Passbook</span></li>
                </ul>
                </div>
                <div className="right-display">{this.renderSwitch()} </div>
        </div>
    );
}

}

export default EmployeeContainer;
