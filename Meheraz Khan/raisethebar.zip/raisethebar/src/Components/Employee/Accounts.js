import React from 'react';

class Accounts extends React.Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    render() {
        return (
            <div className="addEmployee-form">
                <p className="addEmployee-heading">Wallet Balance : Rs 45</p>
                <p className="addEmployee-heading">Add money to your wallet</p>
                <span><input type="text" placeholder="Amount" required />
                </span><br />
                <button type="submit" className="button position">Proceed To Add Money</button>
            </div>
        );
    }

}

export default Accounts;
