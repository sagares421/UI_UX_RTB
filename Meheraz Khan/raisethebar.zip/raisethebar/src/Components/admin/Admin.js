import React from 'react';
import AddEmplyeeForm from './AddEmplyeeForm';
import EmployeeList from './EmployeeList';
import DailyItems from './DailyItems';
import Menu from './Menu';

class Admin extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            addClass: ''
        }
    }

    renderSwitch() {
        switch (this.state.addClass) {
            case 'add':
              return <AddEmplyeeForm />;
            case 'view':
                return <EmployeeList/>
                ;
                case 'current':
                return <DailyItems />;
              case 'menu':
                  return <Menu/>;
        }
    }

    handleClick(id) {
        
        this.setState({
            addClass: id
        });
    }

render(){
    return (
        <div className="admin-portal">
            <p className="admin-heading">Welcome to Admin Portal!</p>
            <div className="left-menu">
            <ul className="list-style-none">
                <li className="admin-option" onClick={this.handleClick.bind(this, 'add')}><span>Add New Employees</span></li>
                <li className="admin-option"  onClick={this.handleClick.bind(this, 'view')}><span >View Employees</span></li>
                <li className="admin-option" onClick={this.handleClick.bind(this, 'current')}><span>Items Of The Day</span></li>
                <li className="admin-option"  onClick={this.handleClick.bind(this, 'menu')}><span >Available Items</span></li>
                </ul>
                </div>
                <div className="right-display">{this.renderSwitch()} </div>
        </div>
    );
}

}

export default Admin;
