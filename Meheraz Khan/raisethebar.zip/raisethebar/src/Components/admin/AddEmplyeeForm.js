import React from 'react';


function AddEmplyeeForm() {
  return (
    <div>
      <form className="addEmployee-form">
        <p className="addEmployee-heading">Add An Employee</p>
        <input type="text" placeholder="Employee Name" />
        <input type="text" placeholder="Employee ID" />
        <input type="text" placeholder="Balance Amount" />
        <input type="submit" className="submit-button" value="Add Employee" />
      </form>
    </div>
  );
}

export default AddEmplyeeForm;
