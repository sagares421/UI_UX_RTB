import React from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/dist/styles/ag-grid.css";
import "ag-grid-community/dist/styles/ag-theme-balham.css";

class DailyItems extends React.Component {
  constructor(props) {
    super(props);
    this.columns = ['Item', 'Price', 'Quantity']
    this.schemaData = [
      {'Item' : 'Pasta', 'Price' : '10', 'Quantity' : '10'},
      {'Item' : 'Noodles', 'Price' : '20', 'Quantity' : '12'},
      {'Item' : 'Samosa', 'Price' : '15', 'Quantity' : '15'},
      {'Item' : 'Tea', 'Price' : '10', 'Quantity' : '8'},
      {'Item' : 'Coffee', 'Price' : '20', 'Quantity' : '9'},
      {'Item' : 'Maggi', 'Price' : '15', 'Quantity' : '7'},
      {'Item' : 'Pizza', 'Price' : '12', 'Quantity' : '15'},
      {'Item' : 'Patties', 'Price' : '18', 'Quantity' : '10'},
      {'Item' : 'Ice Cream', 'Price' : '15', 'Quantity' : '11'},
      {'Item' : 'Noodles', 'Price' : '20', 'Quantity' : '16'},
      {'Item' : 'Chips', 'Price' : '15', 'Quantity' : '12'},
      {'Item' : 'Manchurian', 'Price' : '10', 'Quantity' : '19'},
      {'Item' : 'Idli', 'Price' : '10', 'Quantity' : '23'},
      {'Item' : 'Dosa', 'Price' : '10', 'Quantity' : '7'}
    ]
  }

  displaySchemaHeader(){
    let colDefs = [];
this.columns.map(item => {
  if(this.props.typename == 'dailymenu') {
    let colObj = {
      headerName: item,
      field : item,
      sortable : true,
      width : 395,
      filter : true
    }
    colDefs.push(colObj); 
  }

  else {
    let colObj = {
      headerName: item,
      field : item,
      sortable : true,
      width : 395,
      filter : true,
      editable: true
    }
    colDefs.push(colObj); 
  }
         
})
return colDefs
 }
    
    displaySchemaData() {
      let rowData = []
      let schemaData = this.schemaData;
      schemaData.map(rows => {
        let obj= {}
        this.columns.map(cols => {
          obj[cols] = rows[cols];
        })
        rowData.push(obj);
      })
      return rowData
    }


    emptyGrid() {
    //   console.log(this.schemaData, 'this.schemaData1')
    //   let emptyArray = []
    //  this.schemaData = emptyArray;

    //   console.log(this.schemaData, 'this.schemaData')

    }

  render() {
    return (
      <div className="col-lg-12">
          <button onClick={this.emptyGrid.bind(this)}>Clear Data</button>
           <div
              style={{ height: "500px", width: "100%" }}
              className="ag-theme-balham"
            >
              <AgGridReact 
                columnDefs={this.displaySchemaHeader()}
                rowData={this.displaySchemaData()}
              />
            </div>
            </div>

    )}}
    export default DailyItems