import React from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/dist/styles/ag-grid.css";
import "ag-grid-community/dist/styles/ag-theme-balham.css";

class EmployeeList extends React.Component {
  constructor(props) {
    super(props);
    this.columns = ['Employee Name', 'Employee ID', 'Balance Amount']
    this.schemaData = [
      {'Employee Name' : 'Meheraz Khan', 'Employee ID' : 'IIIPL12', 'Balance Amount' : '100'},
      {'Employee Name' : 'Anand Trivedi', 'Employee ID' : 'IIIPL45', 'Balance Amount' : '120'},
      {'Employee Name' : 'Yash Sankhala', 'Employee ID' : 'IIIPL42', 'Balance Amount' : '150'},
      {'Employee Name' : 'Paridhi Jain', 'Employee ID' : 'IIIPL34', 'Balance Amount' : '80'},
      {'Employee Name' : 'Saloni Sharma', 'Employee ID' : 'IIIPL89', 'Balance Amount' : '90'},
      {'Employee Name' : 'Mayank Bhalotkar', 'Employee ID' : 'IIIPL451', 'Balance Amount' : '70'},
      {'Employee Name' : 'Cijo KB', 'Employee ID' : 'IIIPL412', 'Balance Amount' : '150'},
      {'Employee Name' : 'Sumit Chauhan', 'Employee ID' : 'IIIPL987', 'Balance Amount' : '100'},
      {'Employee Name' : 'Mayank Gupta', 'Employee ID' : 'IIIPL098', 'Balance Amount' : '110'},
      {'Employee Name' : 'Sarbashish Mishra', 'Employee ID' : 'IIIPL76', 'Balance Amount' : '160'},
      {'Employee Name' : 'Vivek Verma', 'Employee ID' : 'IIIPL654', 'Balance Amount' : '120'},
      {'Employee Name' : 'Shivam Rathore', 'Employee ID' : 'IIIPL984', 'Balance Amount' : '190'},
      {'Employee Name' : 'Richa Shah', 'Employee ID' : 'IIIPL654', 'Balance Amount' : '230'},
      {'Employee Name' : 'Anuj Jain', 'Employee ID' : 'IIIPL87', 'Balance Amount' : '70'},
      {'Employee Name' : 'Akanksha Rathore', 'Employee ID' : 'IIIPL19', 'Balance Amount' : '50'},
      {'Employee Name' : 'Aishwarya Kothari', 'Employee ID' : 'IIIPL65', 'Balance Amount' : '120'},
      {'Employee Name' : 'Surbhi Goyal', 'Employee ID' : 'IIIPL96', 'Balance Amount' : '160'}
    ]
  }

  displaySchemaHeader(){
    
    let colDefs = [];
this.columns.map(item => {
  let colObj = {
          headerName: item,
          field : item,
          sortable : true,
          width : 395,
          filter: true,
          editable: true,
        }
        colDefs.push(colObj);  
})
return colDefs
 }
    
    displaySchemaData() {
      let rowData = []
      let schemaData = this.schemaData;
      schemaData.map(rows => {
        let obj= {}
        this.columns.map(cols => {
          obj[cols] = rows[cols];
        })
        rowData.push(obj);
      })
      return rowData
    }


  render() {
    return (
      <div className="col-lg-12">
           <div
              style={{ height: "500px", width: "100%" }}
              className="ag-theme-balham"
            >
              <AgGridReact 
                columnDefs={this.displaySchemaHeader()}
                rowData={this.displaySchemaData()}
              />
            </div>
            </div>

    )}}
    export default EmployeeList
