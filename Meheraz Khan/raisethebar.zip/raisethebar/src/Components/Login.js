import React from 'react';
import { Link, Redirect } from 'react-router-dom';
import EmployeeForm from './EmployeeForm';
import history from '../history';

class Login extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            username: '',
            password: '',
            route : false
        }
    }

    handleLogin = event => {
        this.setState({ username: event.target.value });
    };

    handlePassword = event => {
        this.setState({ password: event.target.value });
    };


    handleSubmit = () =>{
        let url = 'http://localhost:3001/login';
        let logindetails = {
            'user' : this.state.username,
            'password' : this.state.password
        }
        fetch(url, {
            method: "post",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(logindetails)
        })
        .then( (response) => { 
            console.log(response);
            if(response.ok){
                history.push('/admin');
                window.location.reload();
            }
        });
    };





    render() {
        return (
            <div className="wrapper fadeInDown">
                <div id="formContent">
                    
                        <p className="Login-heading"> ADMIN</p>
                        <input type="text" id="login" className="fadeIn second" name="username" value={this.state.username} placeholder="Login" onChange={this.handleLogin} required />
                        <input type="password" id="password" className="fadeIn third" name="login" value={this.state.password} placeholder="Password" onChange={this.handlePassword} />
                         <button type="submit" className="fadeIn fourth button" onClick={this.handleSubmit.bind(this)}>Log In</button>
                    
                </div>
                    <EmployeeForm />
                </div>
        );
    }

}

export default Login;
