import React from 'react';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';
import Login from './Login';
import MenuList from './admin/MenuList';
import SignupForm from './SignupForm';
import Admin from './admin/Admin';
import history from '../history';
import EmployeeContainer from './Employee/EmployeeContainer'


function Header() {
    return (
        <Router history={history}>
            <div>
                <nav className="navbar navbar-expand-lg navbar-light bg-light">
                    <div className="" id="navbarNavAltMarkup">
                        <ul className="navbar-nav">
                        <li className="navbar-brand">Canteen Management System</li>
                            <li className="nav-item nav-link logout-button"><Link to="/">Logout</Link></li>
                        </ul>
                    </div>
                </nav>
        <Route exact path = "/" component = {Login} />
        <Route path = "/signup" component = {SignupForm} />
        <Route path = "/admin" component = {Admin} />
        <Route path = "/employee" component = {EmployeeContainer} />
            </div>
        </Router>
    );
}

export default Header;
