import React from 'react';
class SignupForm extends React.Component {

    constructor(props){
      super(props);
      this.state = { username: '' ,
      employeeId : '',
    amount : ''}
    }

    handleEmployeeLogin = event => {
        this.setState({ username: event.target.value});
      };

      handleEmployeePassword = event => {
        this.setState({ employeeId: event.target.value});
      };

      handleAmount = event => {
        this.setState({ amount: event.target.value});
      };
    render() {
        return (
            <div className="wrapper fadeInDown">
                <div id="formContent">
                <form>
                <p className = "Login-heading">Sign Up</p>
                    <input type="text"  className="fadeIn second" name="username" value={this.state.username} placeholder="Username" onChange={this.handleEmployeeLogin} />
                        <input type="password"  className="fadeIn third" name="ID" value={this.state.employeeId} placeholder="USER ID" onChange={this.handleEmployeePassword}/>
                        <input type="text"  className="fadeIn second" name="amount" value={this.state.amount} placeholder="Amount" onChange={this.handleAmount} />
                        <button type="submit" className="fadeIn fourth button">Sign In</button>
                </form>
            </div>
            </div>
        );
    }
}

export default SignupForm;
