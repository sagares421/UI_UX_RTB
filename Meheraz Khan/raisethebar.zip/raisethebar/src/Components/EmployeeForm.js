import React from 'react';
import { Link } from 'react-router-dom';


class Login extends React.Component {
    constructor(props) {
        super(props);
        this.state = { username: '' ,
    password : ''}
    }

    handleEmployeeLogin = event => {
        this.setState({ username: event.target.value});
      };

      handleEmployeePassword = event => {
        this.setState({ password: event.target.value});
      };


    render() {
        return (
<div id="formContent">
            <form>
                    <p className = "Login-heading"> EMPLOYEE</p>
                        <input type="text"  className="fadeIn second" name="username" value={this.state.username} placeholder="Login" onChange={this.handleEmployeeLogin} />
                        <input type="password"  className="fadeIn third" name="login" value={this.state.password} placeholder="Password" onChange={this.handleEmployeePassword}/>
                        <button type="submit" className="fadeIn fourth button">Log In</button>
                    </form>
                    <p>New Employee?<span><Link to="/signup">Sign Up</Link></span></p>
                    </div>

        );
    }

}

export default Login;
